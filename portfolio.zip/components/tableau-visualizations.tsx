export default function TableauVisualizations() {
  const visualizations = [
    {
      title: "NYSERDA Clean Energy Project Contracts Analysis",
      src: "https://public.tableau.com/views/Ashutosh_Quident_energy_Story/NYSERDACleanEnergyProjectContractsAnalysisforEarly-StageCompanies?:language=en-US&:embed=true&:display_count=n&:origin=viz_share_link",
    },
    {
      title: "Job Search for Junior/Entry-Level Roles in Machine Learning",
      src: "https://public.tableau.com/views/Ashutosh_CaseStudyChallenge/JobssearchforjuniorentrylevelrolesinMachineLearningaligneddisciplines?:language=en-US&:embed=true&:display_count=n&:origin=viz_share_link",
    },
    {
      title: "Dashboard 1",
      src: "https://public.tableau.com/views/Dashboards_DataStories_Ashutosh_Choudhari/Dashboard1?:language=en-US&:embed=true&:display_count=n&:origin=viz_share_link",
    },
  ]

  return (
    <section id="tableau" className="py-20 bg-gradient-to-br from-indigo-50 to-purple-100">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-indigo-800">Tableau Visualizations</h2>
        <div className="space-y-12">
          {visualizations.map((viz, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-3 transition-all duration-300"
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-4">{viz.title}</h3>
                <div className="aspect-video">
                  <iframe src={viz.src} width="100%" height="600" className="border-0" allowFullScreen></iframe>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

